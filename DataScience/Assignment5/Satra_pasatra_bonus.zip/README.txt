The R code for question 5 in Assignment 5 is present in file "pasatra_q5.R"

Steps to run the code:
1) Set the R working directory to the location where the input file is present.
2) The input file should have the name "hw5-3d-data.csv". But the data can have any number of dimensions. Only the file name needs to be as specified. 
3) Install the libraries "ADGofTest" and "cluster". 
4) Finally source the code using source command or use the top right button in Rstudio after opening the R file to execute the R code. 
5) Output will be available as a plot. The plot contains the required clusters and regions defining those clusters.