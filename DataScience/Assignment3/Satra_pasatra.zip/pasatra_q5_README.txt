The basic requirements
1. Install R 3.2.2 - https://www.r-project.org/
2. Install R Studio for the required platform. - https://www.rstudio.com/products/rstudio/download/

After installation of R follow the following steps to run the program 
STEP1: 
Open the file "pasatra_question5.R" in R Studio

STEP2:
Copy the data files in the working directory of RStudio.

STEP3: 
Go to the part of the question 4 which needs to be run as marked in the file. Then keep pressing the "Run" button on top which runs each line till the section of the question is over. 

STEP4: 
Once the section is completely executed the results will be present in the console.